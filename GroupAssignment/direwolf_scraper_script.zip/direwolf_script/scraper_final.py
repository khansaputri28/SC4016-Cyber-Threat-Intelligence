#!/usr/bin/env python3

#################################################
# FOR DIREWOLF RANSOMWARE INTEL PROJECT
# 1. Create a folder with this file in it
# 2. Open a terminal and cd to this folder
# 3. Run the following in order:
# sudo apt update
# sudo apt install -y python3-venv tor curl
# source .venv/bin/activate
# python -m pip install -r requirements.txt
# sudo systemctl start tor
# ss -ltn | grep ':9050' (Confirm that tor is listening on port 9050)
# curl -q --fail --silent --show-error --max-time 60 --noproxy '' --proxy socks5h://127.0.0.1:9050 https://check.torproject.org/api/ip 
# (confirm that you are able to see "IsTor": true" in the output)
# 4. Run the scraper on Direwolf Articles:
# python scraper.py --base-url 'http://<DIREWOLF ONION>.onion' --start <1st desired article> --end <last desired article> --output <output>.csv
# 5. To end, run the following command:
# sudo systemctl stop tor
# deactivate
#################################################

import argparse
import csv
import json
import random
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup


DEFAULT_TOR_PROXY = "socks5h://127.0.0.1:9050"
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
MIN_DELAY_SECONDS = 15

# clean text by removing spaces and to handle empty values
def clean(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()

# load scraper settings from a JSON file
def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

# create a web session sending HTTP and HTTPS through tor proxy
def tor_session(proxy):
    s = requests.Session()
    s.trust_env = False
    s.proxies.update({
        "http": proxy,
        "https": proxy,
    })
    s.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) "
            "Gecko/20100101 Firefox/128.0"
        )
    })
    return s

# verify current connection is successfully routed through tor
def verify_tor(session):
    print("[*] Verifying Tor route...")

    r = session.get(
        "https://check.torproject.org/api/ip",
        timeout=60,
        allow_redirects=False,
    )

    r.raise_for_status()
    data = r.json()

    if data.get("IsTor") is not True:
        raise RuntimeError("Tor check failed: IsTor is not true")

    print(f"[+] Tor confirmed. Exit IP: {data.get('IP', 'unknown')}")

# download html safely while reject redirects, non-HTML responses, and large responses
def fetch_html(session, url):
    r = session.get(
        url,
        timeout=60,
        allow_redirects=False,
        stream=True,
    )

    if r.is_redirect or 300 <= r.status_code < 400:
        raise RuntimeError(f"Redirect rejected (HTTP {r.status_code})")

    if r.status_code == 404:
        return None, 404

    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")

    content_type = r.headers.get("Content-Type", "").lower()

    if "text/html" not in content_type:
        raise RuntimeError(
            f"Non-HTML response rejected: {content_type}"
        )

    content = bytearray()

    for chunk in r.iter_content(chunk_size=16384):
        if not chunk:
            continue

        content.extend(chunk)

        if len(content) > MAX_RESPONSE_BYTES:
            raise RuntimeError("Response exceeded 2 MB safety limit")

    return bytes(content), r.status_code

# extract test from first HTML element that matches a CSS selector
def extract_css_text(soup, selector):
    if not selector:
        return ""

    node = soup.select_one(selector)

    if not node:
        return ""

    return clean(node.get_text(" ", strip=True))

# finds value in an HTML table by matching common labels like business, industry etc.
def extract_table_value(soup, labels):
    """
    Flexible label/value extractor.

    Supports common layouts such as:
      <tr><td>Business</td><td>Company X</td></tr>

    and less tidy layouts where the matching label <td>
    still has a next sibling <td>.
    """

    wanted = {
        clean(x).lower().rstrip(":")
        for x in labels
    }

    # search rows and use first two cells.
    for row in soup.find_all("tr"):
        cells = row.find_all(["td", "th"])

        if len(cells) < 2:
            continue

        key = clean(
            cells[0].get_text(" ", strip=True)
        ).lower().rstrip(":")

        if key in wanted:
            return clean(
                cells[1].get_text(" ", strip=True)
            )

    # find any matching cell and grab next cell sibling.
    for cell in soup.find_all(["td", "th"]):
        key = clean(
            cell.get_text(" ", strip=True)
        ).lower().rstrip(":")

        if key not in wanted:
            continue

        sibling = cell.find_next_sibling(["td", "th"])

        if sibling:
            return clean(
                sibling.get_text(" ", strip=True)
            )

    return ""

# split business field into victim name, website and business description
def parse_business(value):
    """
    Parses common strings such as:

      TrainMe (trainme.co) - French marketplace...

    into:
      company_name
      company_website
      business_description
    """

    value = clean(value)

    if not value:
        return "", "", ""

    company = value
    website = ""
    description = ""

    m = re.match(
        r"^\s*(.*?)\s*\(([^)]+)\)\s*(?:[-–—]\s*(.*))?$",
        value
    )

    if m:
        company = clean(m.group(1))
        website = clean(m.group(2))
        description = clean(m.group(3))
        return company, website, description

    parts = re.split(
        r"\s+[-–—]\s+",
        value,
        maxsplit=1
    )

    company = clean(parts[0])

    if len(parts) > 1:
        description = clean(parts[1])

    return company, website, description

# return the publication date
def parse_published_date(raw):
    raw = clean(raw)

    if not raw:
        return ""

    return re.sub(
        r"^Published:\s*",
        "",
        raw,
        flags=re.I
    )

# extracts only the names of sensitive-data categories from page
def extract_sensitive_topics(soup, cfg):
    """
    Extract only topic/category names from tables with headers
    such as Topic / Records / Sensitive Content.

    This intentionally does NOT save detailed sensitive contents.
    """

    topics = []

    topic_header = (
        cfg["sensitive_topics"]["topic_header"]
        .lower()
    )

    records_header = (
        cfg["sensitive_topics"]["records_header"]
        .lower()
    )

    for table in soup.find_all("table"):

        headers = [
            clean(th.get_text(" ", strip=True)).lower()
            for th in table.find_all("th")
        ]

        if (
            topic_header not in headers
            or records_header not in headers
        ):
            continue

        for row in table.find_all("tr"):

            cells = row.find_all("td")

            if len(cells) < 2:
                continue

            topic = clean(
                cells[0].get_text(" ", strip=True)
            )

            if (
                topic
                and topic.lower() != topic_header
            ):
                topics.append(topic)

    # Dont duplicate while preserving the order
    return "; ".join(dict.fromkeys(topics))

# take the first number found in a text value
def first_integer(text):
    if not text:
        return ""

    m = re.search(
        r"\b([\d,]+)\b",
        text
    )

    return m.group(1) if m else ""

# extract first file size value like MB, GB, TB from a text value
def first_size(text):
    if not text:
        return ""

    m = re.search(
        r"(?i)(~?\s*[\d,.]+\s*(?:KB|MB|GB|TB|KiB|MiB|GiB|TiB))",
        text
    )

    return clean(m.group(1)) if m else ""

# parse document count from phrases
def parse_document_count(total_size_text):
    """
    Conservative extraction from phrases such as:
      ~2.8 GB, 91 non-empty JSONL table files, ...
    """

    if not total_size_text:
        return ""

    patterns = [
        r"(?i)\b([\d,]+)\s+(?:non-empty\s+)?(?:JSONL\s+)?table files\b",
        r"(?i)\b([\d,]+)\s+documents?\b",
        r"(?i)\b([\d,]+)\s+files\b",
    ]

    for pattern in patterns:
        m = re.search(
            pattern,
            total_size_text
        )

        if m:
            return m.group(1)

    return ""

# parse one ransomware article page on victim metadata
def parse_article(html, article_url, cfg):
    soup = BeautifulSoup(
        html,
        "html.parser"
    )

    labels = cfg["labels"]

    business_raw = extract_table_value(
        soup,
        labels["business"]
    )

    (
        company_name,
        company_website,
        business_description,
    ) = parse_business(business_raw)

    published_raw = extract_css_text(
        soup,
        cfg["selectors"]["published_date"]
    )

    published_date = parse_published_date(
        published_raw
    )

    industry = extract_table_value(
        soup,
        labels["industry"]
    )

    total_size_raw = extract_table_value(
        soup,
        labels["total_size"]
    )

    critical_summary = extract_table_value(
        soup,
        labels["critical_sensitive_data"]
    )

    user_count_raw = extract_table_value(
        soup,
        labels["users"]
    )

    customer_count_raw = extract_table_value(
        soup,
        labels["customers"]
    )

    collections_raw = extract_table_value(
        soup,
        labels["collections"]
    )

    document_count_raw = extract_table_value(
        soup,
        labels["documents"]
    )

    topic_categories = extract_sensitive_topics(
        soup,
        cfg
    )

    leaked_data_types = (
        topic_categories
        or critical_summary
    )

    return {
        "company_name": company_name,
        "company_website": company_website,
        "business_description": business_description,
        "industry": industry,
        "published_date_raw": published_raw,
        "published_date": published_date,
        "file_size_raw": total_size_raw,
        "file_size": first_size(total_size_raw),
        "document_count": (
            first_integer(document_count_raw)
            if document_count_raw
            else parse_document_count(total_size_raw)
        ),
        "user_count": first_integer(user_count_raw),
        "customer_count": first_integer(customer_count_raw),
        "collections": first_integer(collections_raw),
        "leaked_data_types": leaked_data_types,
        "critical_data_summary": critical_summary,
    }

# main function that handle arguments, run scraper and write results to CSV
def main():
    parser = argparse.ArgumentParser(
        description=(
            "Low-rate public metadata scraper for "
            "/article/<id> onion pages."
        )
    )

    parser.add_argument(
        "--base-url",
        required=True,
        help=(
            "Base onion URL only, e.g. "
            "http://exampleexampleexample.onion"
        )
    )

    parser.add_argument(
        "--start",
        type=int,
        required=True
    )

    parser.add_argument(
        "--end",
        type=int,
        required=True
    )

    parser.add_argument(
        "--config",
        default="selectors.json"
    )

    parser.add_argument(
        "--output",
        default="victims.csv"
    )

    parser.add_argument(
        "--tor-proxy",
        default=DEFAULT_TOR_PROXY
    )

    parser.add_argument(
        "--delay",
        type=float,
        default=MIN_DELAY_SECONDS
    )

    args = parser.parse_args()

    if args.start > args.end:
        raise SystemExit(
            "--start must be <= --end"
        )

    parsed = urlparse(
        args.base_url
    )

    if parsed.scheme not in (
        "http",
        "https",
    ):
        raise SystemExit(
            "Base URL must start with "
            "http:// or https://"
        )

    if (
        not parsed.hostname
        or not parsed.hostname.endswith(".onion")
    ):
        raise SystemExit(
            "Base URL must be a .onion hostname"
        )

    if parsed.path not in (
        "",
        "/",
    ):
        raise SystemExit(
            "Use only the onion origin as "
            "--base-url, not /article/..."
        )

    cfg = load_config(
        args.config
    )

    session = tor_session(
        args.tor_proxy
    )

    try:
        verify_tor(
            session
        )
    except Exception as exc:
        raise SystemExit(
            f"[!] Tor verification failed: {exc}"
        )

    columns = [
        "article_id",
        "article_url",
        "company_name",
        "company_website",
        "business_description",
        "industry",
        "published_date",
        "published_date_raw",
        "file_size",
        "file_size_raw",
        "document_count",
        "user_count",
        "customer_count",
        "collections",
        "leaked_data_types",
        "critical_data_summary",
        "observed_at_utc",
        "http_status",
        "parse_status",
    ]

    output = Path(
        args.output
    )

    new_file = (
        not output.exists()
    )

    with output.open(
        "a",
        newline="",
        encoding="utf-8-sig"
    ) as csv_file:

        writer = csv.DictWriter(
            csv_file,
            fieldnames=columns
        )

        if new_file:
            writer.writeheader()

        for article_id in range(
            args.start,
            args.end + 1
        ):

            article_url = (
                args.base_url.rstrip("/")
                + f"/article/{article_id}"
            )

            observed_at = (
                datetime.now(timezone.utc)
                .isoformat()
            )

            row = {
                key: ""
                for key in columns
            }

            row.update({
                "article_id": article_id,
                "article_url": article_url,
                "observed_at_utc": observed_at,
            })

            print(
                f"[*] Fetching article {article_id}: "
                f"{article_url}"
            )

            try:
                html, status = fetch_html(
                    session,
                    article_url
                )

                row["http_status"] = status

                if status == 404:
                    row["parse_status"] = "not_found"
                    print(
                        "    [-] 404 not found"
                    )

                else:
                    parsed_data = parse_article(
                        html,
                        article_url,
                        cfg
                    )

                    row.update(
                        parsed_data
                    )

                    if (
                        row["company_name"]
                        or row["published_date"]
                    ):
                        row["parse_status"] = "parsed"

                        print(
                            "    [+] "
                            f"{row['company_name'] or '(no company name)'} "
                            f"{row['published_date'] or ''}"
                        )

                    else:
                        row["parse_status"] = (
                            "html_received_manual_review"
                        )

                        print(
                            "    [!] HTML received but "
                            "key fields were not parsed"
                        )

            except Exception as exc:

                row["parse_status"] = (
                    f"error: {exc}"
                )

                print(
                    f"    [!] {exc}"
                )

            writer.writerow(
                row
            )

            csv_file.flush()

            if article_id != args.end:

                delay = (
                    max(
                        args.delay,
                        MIN_DELAY_SECONDS
                    )
                    + random.uniform(0, 3)
                )

                print(
                    f"    [*] Waiting "
                    f"{delay:.1f}s"
                )

                time.sleep(
                    delay
                )

    print()
    print(
        "[+] Finished. CSV saved to:"
    )
    print(
        output.resolve()
    )

# run the main function when the script is executed directly
if __name__ == "__main__":
    main()
