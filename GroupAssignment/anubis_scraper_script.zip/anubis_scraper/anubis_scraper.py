from bs4 import BeautifulSoup
import csv

OUTPUT_CSV = "anubis_victims_all.csv"

def main():
    all_victims = []

    print("Opening local victims.html file...")
    try:
        with open('anubis_victims.html', 'r', encoding='utf-8') as f:
            soup = BeautifulSoup(f, 'html.parser')
    except FileNotFoundError:
        print("Error: Could not find 'victims.html'.")
        return

    # 1. The Main Box (Targeting the specific card background color)
    cards = soup.find_all('div', class_='bg-secondary-2') 
    print(f"Found {len(cards)} total victim entries. Extracting data...")
    
    for card in cards:
        try:
            # 2. The Name (The first <h5> tag with 'fw-bold')
            name_tag = card.find('h5', class_='fw-bold')
            name = name_tag.text.strip() if name_tag else "Unknown"
            
            # 3. The Industry / Size Badge (The <span> with 'badge')
            badge_tag = card.find('span', class_='badge')
            industry_size = badge_tag.text.strip() if badge_tag else "No Badge"
            
            # 4. The Description (The second <h5> tag in the box)
            h5_tags = card.find_all('h5', class_='fw-bold')
            if len(h5_tags) > 1:
                description = h5_tags[1].text.strip().replace('\n', ' ')
            else:
                description = "No description"

            # Save the victim to our list
            all_victims.append({
                'name': name, 
                'date': 'Unknown (2026)', 
                'industry_size': industry_size,
                'details': description
            })
        
        except Exception:
            continue

    # Save to CSV
    print(f"Success! Saving {len(all_victims)} victims to {OUTPUT_CSV}...")
    fieldnames = ['name', 'date', 'industry_size', 'details']
    
    with open(OUTPUT_CSV, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_victims)
        
    print("Done! You just beat the dark web.")

if __name__ == '__main__':
    main()
